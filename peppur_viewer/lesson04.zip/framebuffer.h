#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include <psptypes.h>

extern u32* g_vram_base;

#endif
